from pathlib import Path
from random import choice
import pygame
from pytmx.util_pygame import load_pygame
from settings import *
from support import *

BASE_DIR = Path(__file__).resolve().parent


def resolve_path(rel_path: str) -> str:
	path = BASE_DIR / rel_path
	return str(path)


def safe_import_folder(rel_path: str):
	full_path = BASE_DIR / rel_path
	if full_path.exists():
		frames = import_folder(str(full_path))
		if frames:
			return frames
	fallback = pygame.Surface((TILE_SIZE, TILE_SIZE), pygame.SRCALPHA)
	fallback.fill((80, 170, 70))
	return [fallback]


def safe_import_folder_dict(rel_path: str):
	full_path = BASE_DIR / rel_path
	if full_path.exists():
		surfs = import_folder_dict(str(full_path))
		if surfs:
			return surfs
	fallback = pygame.Surface((TILE_SIZE, TILE_SIZE), pygame.SRCALPHA)
	fallback.fill((145, 95, 50))
	return {'o': fallback}


def safe_load_sound(rel_path: str, volume: float = 0.1):
	full_path = BASE_DIR / rel_path
	if full_path.exists() and pygame.mixer.get_init():
		sound = pygame.mixer.Sound(str(full_path))
		sound.set_volume(volume)
		return sound

	class DummySound:
		def play(self):
			pass

	return DummySound()


class SoilTile(pygame.sprite.Sprite):
	def __init__(self, pos, surf, groups):
		super().__init__(groups)
		self.image = surf
		self.rect = self.image.get_rect(topleft=pos)
		self.z = LAYERS['soil']


class WaterTile(pygame.sprite.Sprite):
	def __init__(self, pos, surf, groups):
		super().__init__(groups)
		self.image = surf
		self.rect = self.image.get_rect(topleft=pos)
		self.z = LAYERS['soil water']


class Plant(pygame.sprite.Sprite):
	def __init__(self, plant_type, groups, soil, check_watered):
		super().__init__(groups)

		# setup
		self.plant_type = plant_type
		self.frames = safe_import_folder(f'graphics/fruit/{plant_type}')
		self.soil = soil
		self.check_watered = check_watered

		# plant growing
		self.age = 0
		self.max_age = len(self.frames) - 1
		self.GROW_SPEED = GROW_SPEED[plant_type]
		self.harvestable = False

		# sprite setup
		self.image = self.frames[self.age]
		self.y_offset = -16 if plant_type == 'corn' else -8
		self.rect = self.image.get_rect(
			midbottom=soil.rect.midbottom + pygame.math.Vector2(0, self.y_offset)
		)
		self.z = LAYERS['ground plant']

	def grow(self):
		if self.check_watered(self.rect.center):
			self.age += self.GROW_SPEED

			if int(self.age) > 0:
				self.z = LAYERS['main']
				self.hitbox = self.rect.copy().inflate(-26, -self.rect.height * 0.4)

			if self.age >= self.max_age:
				self.age = self.max_age
				self.harvestable = True

			self.image = self.frames[int(self.age)]
			self.rect = self.image.get_rect(
				midbottom=self.soil.rect.midbottom + pygame.math.Vector2(0, self.y_offset)
			)


class SoilLayer:
	def __init__(self, all_sprites, collision_sprites):

		# sprite groups
		self.all_sprites = all_sprites
		self.collision_sprites = collision_sprites
		self.soil_sprites = pygame.sprite.Group()
		self.water_sprites = pygame.sprite.Group()
		self.plant_sprites = pygame.sprite.Group()

		# graphics
		self.soil_surfs = safe_import_folder_dict('graphics/soil/')
		self.water_surfs = safe_import_folder('graphics/soil_water')

		self.create_soil_grid()
		self.create_hit_rects()

		# sounds
		self.hoe_sound = safe_load_sound('audio/hoe.wav', 0.1)
		self.plant_sound = safe_load_sound('audio/plant.wav', 0.1)

	def create_soil_grid(self):
		ground_path = BASE_DIR / 'graphics/world/ground.png'
		if ground_path.exists():
			ground = pygame.image.load(str(ground_path))
			h_tiles = ground.get_width() // TILE_SIZE
			v_tiles = ground.get_height() // TILE_SIZE
		else:
			h_tiles, v_tiles = 40, 30

		self.grid = [[[] for _ in range(h_tiles)] for _ in range(v_tiles)]

		map_path = BASE_DIR / 'data/map.tmx'
		if map_path.exists():
			tmx_data = load_pygame(str(map_path))
			farmable_layer = tmx_data.get_layer_by_name('Farmable')
			for x, y, _ in farmable_layer.tiles():
				if 0 <= y < v_tiles and 0 <= x < h_tiles:
					self.grid[y][x].append('F')

	def create_hit_rects(self):
		self.hit_rects = []
		for index_row, row in enumerate(self.grid):
			for index_col, cell in enumerate(row):
				if 'F' in cell:
					x = index_col * TILE_SIZE
					y = index_row * TILE_SIZE
					rect = pygame.Rect(x, y, TILE_SIZE, TILE_SIZE)
					self.hit_rects.append(rect)

	def get_hit(self, point):
		for rect in self.hit_rects:
			if rect.collidepoint(point):
				self.hoe_sound.play()
				x = rect.x // TILE_SIZE
				y = rect.y // TILE_SIZE

				if 'F' in self.grid[y][x]:
					self.grid[y][x].append('X')
					self.create_soil_tiles()
					if getattr(self, 'raining', False):
						self.water_all()

	def water(self, target_pos):
		for soil_sprite in self.soil_sprites.sprites():
			if soil_sprite.rect.collidepoint(target_pos):
				x = soil_sprite.rect.x // TILE_SIZE
				y = soil_sprite.rect.y // TILE_SIZE
				self.grid[y][x].append('W')

				pos = soil_sprite.rect.topleft
				surf = choice(self.water_surfs)
				WaterTile(pos, surf, [self.all_sprites, self.water_sprites])

	def water_all(self):
		for index_row, row in enumerate(self.grid):
			for index_col, cell in enumerate(row):
				if 'X' in cell and 'W' not in cell:
					cell.append('W')
					x = index_col * TILE_SIZE
					y = index_row * TILE_SIZE
					WaterTile((x, y), choice(self.water_surfs), [self.all_sprites, self.water_sprites])

	def remove_water(self):
		for sprite in self.water_sprites.sprites():
			sprite.kill()

		for row in self.grid:
			for cell in row:
				if 'W' in cell:
					cell.remove('W')

	def check_watered(self, pos):
		x = int(pos[0]) // TILE_SIZE
		y = int(pos[1]) // TILE_SIZE
		if 0 <= y < len(self.grid) and 0 <= x < len(self.grid[0]):
			return 'W' in self.grid[y][x]
		return False

	def plant_seed(self, target_pos, seed):
		for soil_sprite in self.soil_sprites.sprites():
			if soil_sprite.rect.collidepoint(target_pos):
				self.plant_sound.play()

				x = soil_sprite.rect.x // TILE_SIZE
				y = soil_sprite.rect.y // TILE_SIZE
				if 'P' not in self.grid[y][x]:
					self.grid[y][x].append('P')
					Plant(
						seed,
						[self.all_sprites, self.plant_sprites, self.collision_sprites],
						soil_sprite,
						self.check_watered,
					)

	def update_plants(self):
		for plant in self.plant_sprites.sprites():
			plant.grow()

	def create_soil_tiles(self):
		self.soil_sprites.empty()
		default_surf = next(iter(self.soil_surfs.values()))

		for index_row, row in enumerate(self.grid):
			for index_col, cell in enumerate(row):
				if 'X' in cell:
					t = index_row > 0 and 'X' in self.grid[index_row - 1][index_col]
					b = index_row < len(self.grid) - 1 and 'X' in self.grid[index_row + 1][index_col]
					r = index_col < len(row) - 1 and 'X' in row[index_col + 1]
					l = index_col > 0 and 'X' in row[index_col - 1]

					tile_type = 'o'

					if all((t, r, b, l)):
						tile_type = 'x'

					if l and not any((t, r, b)):
						tile_type = 'r'
					if r and not any((t, l, b)):
						tile_type = 'l'
					if r and l and not any((t, b)):
						tile_type = 'lr'

					if t and not any((r, l, b)):
						tile_type = 'b'
					if b and not any((r, l, t)):
						tile_type = 't'
					if b and t and not any((r, l)):
						tile_type = 'tb'

					if l and b and not any((t, r)):
						tile_type = 'tr'
					if r and b and not any((t, l)):
						tile_type = 'tl'
					if l and t and not any((b, r)):
						tile_type = 'br'
					if r and t and not any((b, l)):
						tile_type = 'bl'

					if all((t, b, r)) and not l:
						tile_type = 'tbr'
					if all((t, b, l)) and not r:
						tile_type = 'tbl'
					if all((l, r, t)) and not b:
						tile_type = 'lrb'
					if all((l, r, b)) and not t:
						tile_type = 'lrt'

					surf = self.soil_surfs.get(tile_type, default_surf)
					SoilTile(
						pos=(index_col * TILE_SIZE, index_row * TILE_SIZE),
						surf=surf,
						groups=[self.all_sprites, self.soil_sprites],
					)