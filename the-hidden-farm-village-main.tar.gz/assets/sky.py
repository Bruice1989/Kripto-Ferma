from pathlib import Path
from random import randint, choice
import pygame
from settings import *
from support import import_folder
from sprites import Generic

BASE_DIR = Path(__file__).resolve().parent


def safe_import_folder(rel_path: str, color=(120, 170, 255), size=(12, 12)):
	full_path = BASE_DIR / rel_path
	if full_path.exists():
		frames = import_folder(str(full_path))
		if frames:
			return frames
	surf = pygame.Surface(size, pygame.SRCALPHA)
	surf.fill(color)
	return [surf]


def safe_ground_size(rel_path: str, fallback=(1280, 720)):
	full_path = BASE_DIR / rel_path
	if full_path.exists():
		return pygame.image.load(str(full_path)).get_size()
	return fallback


class Sky:
	def __init__(self):
		self.display_surface = pygame.display.get_surface()
		self.full_surf = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
		self.start_color = [255,255,255]
		self.end_color = (38,101,189)

	def display(self, dt):
		for index, value in enumerate(self.end_color):
			if self.start_color[index] > value:
				self.start_color[index] -= 5 * dt

		self.full_surf.fill(self.start_color)
		self.display_surface.blit(self.full_surf, (0,0), special_flags = pygame.BLEND_RGBA_MULT)

class Drop(Generic):
	def __init__(self, surf, pos, moving, groups, z):
		
		# general setup
		super().__init__(pos, surf, groups, z)
		self.lifetime = randint(400,500)
		self.start_time = pygame.time.get_ticks()

		# moving 
		self.moving = moving
		if self.moving:
			self.pos = pygame.math.Vector2(self.rect.topleft)
			self.direction = pygame.math.Vector2(-2,4)
			self.speed = randint(200,250)

	def update(self,dt):
		# movement
		if self.moving:
			self.pos += self.direction * self.speed * dt
			self.rect.topleft = (round(self.pos.x), round(self.pos.y))

		# timer
		if pygame.time.get_ticks() - self.start_time >= self.lifetime:
			self.kill()

class Rain:
	def __init__(self, all_sprites):
		self.all_sprites = all_sprites
		self.rain_drops = safe_import_folder('graphics/rain/drops/', (130, 180, 255), (4, 14))
		self.rain_floor = safe_import_folder('graphics/rain/floor/', (150, 200, 255), (12, 6))
		self.floor_w, self.floor_h = safe_ground_size('graphics/world/ground.png', (1280, 720))

	def create_floor(self):
		Drop(
			surf = choice(self.rain_floor), 
			pos = (randint(0,self.floor_w),randint(0,self.floor_h)), 
			moving = False, 
			groups = self.all_sprites, 
			z = LAYERS['rain floor'])

	def create_drops(self):
		Drop(
			surf = choice(self.rain_drops), 
			pos = (randint(0,self.floor_w),randint(0,self.floor_h)), 
			moving = True, 
			groups = self.all_sprites, 
			z = LAYERS['rain drops'])

	def update(self):
		self.create_floor()
		self.create_drops()