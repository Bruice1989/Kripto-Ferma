from pathlib import Path
import pygame
from settings import *

BASE_DIR = Path(__file__).resolve().parent


def safe_load_overlay_icon(rel_path: str, color=(200, 180, 90)):
	full_path = BASE_DIR / rel_path
	if full_path.exists():
		return pygame.image.load(str(full_path)).convert_alpha()
	surf = pygame.Surface((48, 48), pygame.SRCALPHA)
	surf.fill(color)
	return surf


class Overlay:
	def __init__(self, player):

		# general setup
		self.display_surface = pygame.display.get_surface()
		self.player = player

		# imports
		overlay_rel = 'graphics/overlay/'
		self.tools_surf = {
			tool: safe_load_overlay_icon(f'{overlay_rel}{tool}.png', (170, 130, 80))
			for tool in player.tools
		}
		self.seeds_surf = {
			seed: safe_load_overlay_icon(f'{overlay_rel}{seed}.png', (90, 180, 90))
			for seed in player.seeds
		}

	def display(self):

		# tool
		tool_surf = self.tools_surf[self.player.selected_tool]
		tool_rect = tool_surf.get_rect(midbottom=OVERLAY_POSITIONS['tool'])
		self.display_surface.blit(tool_surf, tool_rect)

		# seeds
		seed_surf = self.seeds_surf[self.player.selected_seed]
		seed_rect = seed_surf.get_rect(midbottom=OVERLAY_POSITIONS['seed'])
		self.display_surface.blit(seed_surf, seed_rect)